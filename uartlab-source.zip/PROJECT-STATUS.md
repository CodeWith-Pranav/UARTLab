# UARTLab status — 2026-11-05

Completed: RTL implementation; two self-checking testbenches; portable Makefile; final local simulation; both UART VCDs; waveform PNG derived from VCD; specification, architecture, beginner/interview guides; GitHub Actions workflow; downloadable source package.

Evidence: 6,000 seeded FIFO cycles and seven UART scenario groups at each of CPB=32 and CPB=8 passed. Full logs in results/test-log.txt. Limitations and conditional test scope in docs/VERIFICATION.md.

Not performed: public GitHub publication, remote CI run, Vercel publication (no frontend is required for RTL), FPGA synthesis or hardware validation. The package is ready for a public repository. Resume from this status; preserve finished source and rerun simulations when RTL/test changes require it.
